﻿import os
import NXOpen
import NXOpen.CAE

PATH_DIR_SAVE = os.path.dirname(os.path.realpath(__file__))

def load_solution_results(theSession, simSimulation, sol_name):
    """
    Loads the result data for the simcenter solution instance

    Parameters:
    -----------
    theSession : object
        The NXOpen session object
    simSimulation : object
        The NXOpen simulation object
    sol_name : str
        The solution name

    Returns:
    --------
    solutionResult : object
        Solution object
    """
    simSolution = simSimulation.FindObject("Solution[%s]"%(sol_name)) # Access the solution instance
    simResultReference = simSolution.Find("Structural") # Get the structural result reference for the solution instance
    solutionResult = theSession.ResultManager.CreateReferenceResult(simResultReference) # Access the solution results
    return solutionResult

def create_load_combination(theSession, workSimPart, case_name, unit_ref_solution,
                            result_name, result_type, result_unit_name, lc_iterations, lc_mults):
    """
    Create a load combination solution

    Parameters:
    -----------
    theSession : object
        The NXOpen session object
    workSimPart : object
        The NXOpen work geometry part object
    case_name : str
        The name associated with the combined load case
    unit_ref_solution : object
        Solution from which units will be referenced.
    result_name : str
        The result name.
    result_type : str
        The result type.
    result_unit_name : str
        The result unit name.
    lc_iterations : array-like
        The load case result iterations to probe
    lc_mults : array-like
        The load case multipliers
    """
    # Initialize load combination builder
    resultsCombinationBuilder = theSession.ResultManager.CreateResultsCombinationBuilder()

    # Specify the load case result names, type, and unit
    types = [lc_iteration.Find("ResultType[[%s][%s]]"%(result_name, result_type)) for lc_iteration in lc_iterations]
    names = ['LC%i'%(i_lc+1) for i_lc in range(len(lc_iterations))]
    units = [workSimPart.UnitCollection.FindObject(result_unit_name)]*len(lc_iterations)
    resultsCombinationBuilder.SetResultTypes(types, names, units)

    # Specify the load combination equation
    eq_txt = ''.join(['%s*LC%i + '%(lc_mults[i_lc], i_lc+1) for i_lc in range(len(lc_iterations))])[:-3]
    resultsCombinationBuilder.SetFormula(eq_txt)

    # Specify combined solution creation parameters
    resultsCombinationBuilder.SetOutputResultType(NXOpen.CAE.ResultsManipulationBuilder.OutputResultType.Full)
    resultsCombinationBuilder.SetCreateSolution(True)
    resultsCombinationBuilder.SetImportResult(False)
    resultsCombinationBuilder.SetImportedSolutionName(case_name)
    resultsCombinationBuilder.SetIncludeModel(True)

    # Set output parameters
    if result_name == 'Stress':
        resultsCombinationBuilder.SetOutputQuantity(NXOpen.CAE.Result.Quantity.Stress)
    else:
        raise RuntimeError()
    resultsCombinationBuilder.SetOutputName("")
    resultsCombinationBuilder.SetLoadcaseName("")
    resultsCombinationBuilder.SetOutputFile(os.path.join(PATH_DIR_SAVE, '%s.unv'%case_name))

    # Specify combined solution units
    resultsCombinationBuilder.SetUnitsSystem(NXOpen.CAE.ResultsManipulationBuilder.UnitsSystem.FromResult)
    resultsCombinationBuilder.SetUnitsSystemResult(unit_ref_solution)

    # Set error handling options
    resultsCombinationBuilder.SetIncompatibleResultsOption(NXOpen.CAE.ResultsCombinationBuilder.IncompatibleResults.Skip)
    resultsCombinationBuilder.SetNoDataOption(NXOpen.CAE.ResultsCombinationBuilder.NoData.Skip)
    resultsCombinationBuilder.SetEvaluationErrorOption(NXOpen.CAE.ResultsCombinationBuilder.EvaluationError.Skip)

    # Create the combined load case and remove the load combination builder from memory
    resultsCombinationBuilder.Commit()
    resultsCombinationBuilder.Destroy()

def create_load_envelope(theSession, workSimPart, case_name, unit_ref_solution,
                         fname_sim, sol_names, result_names, result_types, result_unit_names,
                         env_output_name):
    """
    Create a enveloped solution instance

    Parameters:
    -----------
    theSession : object
        The NXOpen session object
    workSimPart : object
        The NXOpen work geometry part object
    case_name : str
        The name associated with the enveloped load case
    unit_ref_solution : object
        Solution from which units will be referenced
    fname_sim : str
        The name of the Simcenter Sim file
    sol_names : list of str
        The solution names
    result_names : list of str
        The result names.
    result_types : list of str
        The result types.
    result_unit_names : list of str
        The result unit names.
    env_output_name : str
        The output name associated with the enveloped response
    """
    # Generate list of solution result information to use in enveloping
    ids = [None] * len(sol_names)
    results = [NXOpen.CAE.Result.Null] * len(sol_names)
    parameters = [NXOpen.CAE.ResultParameters.Null] * len(sol_names)
    for i_sol, (sol_name, result_name, result_type, result_unit_name) in enumerate(zip(sol_names, result_names, result_types, result_unit_names)):

        # Access solution result
        resultManager = theSession.ResultManager
        solutionResult = resultManager.FindObject("SolutionResult[%s_%s]"%(fname_sim, sol_name))
        loadcase = solutionResult.Find("Loadcase[1]")
        iteration = loadcase.Find("Iteration[1]")
        resultType = iteration.Find("ResultType[[%s][%s]]"%(result_name, result_type))

        # Specify result parameters to be used in enveloping
        resultParameters = theSession.ResultManager.CreateResultParameters()
        resultParameters.SetGenericResultType(resultType)
        resultParameters.SetResultShellSection(NXOpen.CAE.Result.Section.Maximum)
        resultParameters.SetResultComponent(NXOpen.CAE.Result.Component.VonMises)
        resultParameters.SetCoordinateSystem(NXOpen.CAE.Result.CoordinateSystem.AbsoluteRectangular)
        resultParameters.SetUnit(workSimPart.UnitCollection.FindObject(result_unit_name))
        resultParameters.SetAbsoluteValue(False)

        # Store case information
        ids[i_sol] = i_sol + 1
        results[i_sol] = solutionResult
        parameters[i_sol] = resultParameters

    # Create the envelope builder
    resultsEnvelopeBuilder = theSession.ResultManager.CreateResultsEnvelopeBuilder()
    resultsEnvelopeBuilder.SetResults(ids, results, parameters)

    # Specify the envelope operation
    resultsEnvelopeBuilder.SetOperation(NXOpen.CAE.ResultsEnvelopeBuilder.Operation.Maximum)

    # Specify enveloped solution creation parameters
    resultsEnvelopeBuilder.SetOutputResultType(NXOpen.CAE.ResultsManipulationBuilder.OutputResultType.Full)
    resultsEnvelopeBuilder.SetCreateSolution(True)
    resultsEnvelopeBuilder.SetImportResult(False)
    resultsEnvelopeBuilder.SetImportedSolutionName(case_name)
    resultsEnvelopeBuilder.SetIncludeModel(True)

    # Set output parameters
    resultsEnvelopeBuilder.SetOutputQuantity(NXOpen.CAE.Result.Quantity.Stress)
    resultsEnvelopeBuilder.SetOutputName(env_output_name)
    resultsEnvelopeBuilder.SetLoadcaseName("")
    resultsEnvelopeBuilder.SetOutputFile(os.path.join(PATH_DIR_SAVE, '%s.unv'%case_name))

    # Specify enveloped solution units
    resultsEnvelopeBuilder.SetUnitsSystem(NXOpen.CAE.ResultsManipulationBuilder.UnitsSystem.FromResult)
    resultsEnvelopeBuilder.SetUnitsSystemResult(unit_ref_solution)

    # Set error handling options
    resultsEnvelopeBuilder.SetIncompatibleResultsOption(NXOpen.CAE.ResultsEnvelopeBuilder.IncompatibleResults.Skip)
    resultsEnvelopeBuilder.SetNoDataOption(NXOpen.CAE.ResultsEnvelopeBuilder.NoData.Skip)

    # Create the enveloped load case and remove the envelope builder from memory
    resultsEnvelopeBuilder.Commit()
    resultsEnvelopeBuilder.Destroy()
    theSession.ResultManager.DeleteResultParameters(resultParameters)

def main() :
    # Inputs
    fname_sim = 'pressure_vessel_fem1_sim1.sim'

    # Instantiate working session reference parameters
    theSession  = NXOpen.Session.GetSession() # Grab the current session
    workSimPart = theSession.Parts.BaseWork   # Access the working part for the current session
    simSimulation = workSimPart.FindObject("Simulation") # Access the simulation object associated to the working part

    # Load unit load cases
    unit_case_names = ['%s Limit Load'%label for label in ['Fx', 'Fy', 'Fz', 'Mx', 'My', 'Mz']]
    solutionResults = [load_solution_results(theSession, simSimulation, cname) for cname in unit_case_names]

    # Access solution results
    lc_iterations = []
    for solutionResult in solutionResults:
        loadcase = solutionResult.Find("Loadcase[1]")
        lc_iterations.append(loadcase.Find("Iteration[1]"))

    # Generate load case multipliers
    vals1, vals2, vals3, vals4, vals5, vals6 = [1, -1], [1, -1], [1, -1], [1, -1], [1, -1], [1, -1]
    lc_mults_list = (
        [[val1, val2, val3, val4, val5, val6]
         for val1 in vals1 for val2 in vals2 for val3 in vals3 for val4 in vals4 for val5 in vals5 for val6 in vals6]
    )

    # Create load combinations
    sol_names_stress_envelope = []
    result_names_stress_envelope = []
    result_types_stress_envelope = []
    result_unit_names_stress_envelope = []
    for i_case,lc_mults in enumerate(lc_mults_list):

        # Create combination load for elemental stress
        result_name = 'Stress'
        result_type = 'Elemental'
        result_unit_name = 'StressPoundForcePerSquareInch'
        case_name = 'Case%s%s'%(i_case+1, result_name)
        create_load_combination(theSession, workSimPart, case_name, solutionResults[0],
                                result_name, result_type, result_unit_name, lc_iterations, lc_mults)
        load_solution_results(theSession, simSimulation, case_name)

        # Store case information for enveloping
        sol_names_stress_envelope.append(case_name)
        result_names_stress_envelope.append(result_name)
        result_types_stress_envelope.append(result_type)
        result_unit_names_stress_envelope.append(result_unit_name)

    # Create load envelope
    case_name = 'EnvelopedStress'
    env_output_name = "Maximum Stress(Von-Mises)"
    create_load_envelope(theSession, workSimPart, case_name, solutionResults[0],
                         fname_sim, sol_names_stress_envelope, result_names_stress_envelope,
                         result_types_stress_envelope, result_unit_names_stress_envelope,
                         env_output_name)
    load_solution_results(theSession, simSimulation, case_name)

if __name__ == '__main__':
    main()