import math

deg = math.pi/180
'''

angle = 20.38 + 90

radian = angle*deg

radian = 79.93*deg
'''
radian = 72.0*deg

print(radian)